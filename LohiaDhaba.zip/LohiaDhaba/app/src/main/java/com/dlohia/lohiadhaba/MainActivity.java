package com.dlohia.lohiadhaba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


// this controls the full application
public class MainActivity extends AppCompatActivity {
    public static final String OrderSummKeyA = "com.dlohia.lohiadhaba.orderA";
    public static final String OrderSummKeyB = "com.dlohia.lohiadhaba.orderB";
    public static final String OrderSummKeyC = "com.dlohia.lohiadhaba.orderC";

    @Override
    // this could be for the first screen
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // this is a event or say send text to other screen view !!
    // place order function runs when its CLICKED. its like on click
    public void placeOrder(View view){
        EditText orderA  = findViewById(R.id.TxtOrder1) ;
        EditText orderB  = findViewById(R.id.TxtOrder2) ;
        EditText orderC  = findViewById(R.id.TxtOrder3) ;

        Boolean err = false;
        //if (odrA == null || odrA.equals(""))
        //if (isEmp (orderA.getText().toString())== false){
        if (TextUtils.isEmpty( orderA.getText() )){
            orderA.setError("Required Field");
            err = true;
        }
        //orderA.setError(null);

        if (TextUtils.isEmpty( orderB.getText() )){
            orderB.setError("Required Field");
            err= true;
        }

        if (TextUtils.isEmpty( orderC.getText() )){
            orderC.setError("Required Field");
            err= true;
        }

        if (err == false){
            // intend is a way of communication between two screens or we can say like we use get and set text in php or other langauges.
            Intent intent  =  new Intent ( this , OrderActivity.class );

            String orderSummary = orderA.getText().toString() + ",  "
                            + orderB.getText().toString()
                            +  " & " + orderC.getText().toString()  ;
            //Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            // YOU ARE SENDING VALUES VIA A KEY
            //intent.putExtra( OrderSummKeyA , orderSummary );
            intent.putExtra( OrderSummKeyA , orderA.getText().toString() );
            intent.putExtra( OrderSummKeyB , orderB.getText().toString() );
            intent.putExtra( OrderSummKeyC , orderC.getText().toString() );
            startActivity(intent);
        }
    }

    /*
    private boolean isEmp(String text) {
        if(text==null || text.equals("")){
            return true;
        }
        else {
            return false;
        }
    }
    */

}