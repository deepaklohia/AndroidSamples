package com.dlohia.lohiadhaba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class OrderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        //activity has been loaded
        Intent intent = getIntent();
        //getting the value that was sent in main activity .
        //String orderSummA = intent.getStringExtra(MainActivity.OrderSummKeyA) ;

        TextView TxtOrder1 = findViewById(R.id.TxtOrder1) ;
        TextView TxtOrder2 = findViewById(R.id.TxtOrder2) ;
        TextView TxtOrder3 = findViewById(R.id.TxtOrder3) ;

        TxtOrder1.setText( intent.getStringExtra(MainActivity.OrderSummKeyA) );
        TxtOrder2.setText( intent.getStringExtra(MainActivity.OrderSummKeyB) );
        TxtOrder3.setText( intent.getStringExtra(MainActivity.OrderSummKeyC) );

    }
}