package com.dlohia.loginactivity.data;

import android.util.Log;

import androidx.annotation.NonNull;
import com.dlohia.loginactivity.data.model.LoggedInUser;
import java.io.IOException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {

    FirebaseAuth mAuth  ;
    FirebaseUser mUser  ;
    boolean loginSuccess  ;


    public Result<LoggedInUser> login(String username, String password) {

        Log.d("log99", "data src log");
        loginSuccess = false ;

        Log.d("log99", username +  password  );

        mAuth  =  FirebaseAuth.getInstance()  ;
        mUser  = mAuth.getCurrentUser()  ;

        try {
            mAuth.signInWithEmailAndPassword(username  , password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        loginSuccess = true ;
                        Log.d("log99", "login success");
                        //Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.d("log99", "login fail on firebase");
                        //Toast.makeText(MainActivity.this, "invalid user name or password", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            if (loginSuccess){
                LoggedInUser fakeUser =
                        new LoggedInUser( mAuth.getCurrentUser().toString(),
                                "Deepak Lohia");
                return new Result.Success<>(fakeUser);
            }
            else{
                return new Result.Success<>("none");
            }

            // TODO: handle loggedInUser authentication
            /*
            LoggedInUser fakeUser =
                    new LoggedInUser(
                            java.util.UUID.randomUUID().toString(),
                            "Jane Doe");
            return new Result.Success<>(fakeUser);

             */

        } catch (Exception e) {
            Log.d("log99", e.getMessage().toString()   );
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public void logout() {
        // TODO: revoke authentication
    }
}