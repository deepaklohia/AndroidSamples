package com.example.learngurjari;

import android.app.Dialog;
import com.example.learngurjari.R.layout.*;
import com.example.learngurjari.R ;

public class checkInternet {

    public static String checkName(String n){
        if (n != "ramu"){
            return "ramu nahi hai" ;
        }
        else{
            return "ramu naam hai " ;
        }
    }

}


