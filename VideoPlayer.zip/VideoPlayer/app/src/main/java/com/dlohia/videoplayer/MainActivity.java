package com.dlohia.videoplayer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    MediaPlayer mediaPlayer  ;
    SeekBar seekBar  ;
    Button btnPlayPause ;
    SurfaceView surfaceView ;

    MediaPlayer mediaPlayer2  ;
    SeekBar seekBar2  ;
    Button btnPlayPause2 ;
    SurfaceView surfaceView2 ;
    TextView buffer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //OFFLINE VIDEO PLAY
        surfaceView = findViewById(R.id.surfaceView) ;
        seekBar = findViewById( R.id.seekBar) ;
        btnPlayPause  = findViewById( R.id.btnPlayPause)  ;

        mediaPlayer = MediaPlayer.create(this , R.raw.cowndown)  ;
        surfaceView.setKeepScreenOn(true);

        SurfaceHolder surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {
                mediaPlayer.setDisplay(surfaceHolder);
            }
            @Override
            public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {
            }
            @Override
            public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {
            }
        });

        seekBar.setMax( ( mediaPlayer.getDuration())  );
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean user) {
                //if ( user ){
                //mediaPlayer.seekTo(progress);
                if(mediaPlayer != null && user){
                    mediaPlayer.seekTo(progress );
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                btnPlayPause.setText(R.string.btnPlay);
                mediaPlayer.seekTo(0);
                //mediaPlayer2.prepareAsync();
            }
        });

        btnPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ( mediaPlayer.isPlaying() ){
                    mediaPlayer.pause();
                    btnPlayPause.setText(R.string.btnPlay);
                }
                else {
                    mediaPlayer.start();
                    btnPlayPause.setText(R.string.btnPause);
                }
            }
        });

        Handler mHandler = new Handler();
        //Make sure you update Seekbar on UI thread
        MainActivity.this.runOnUiThread(new Runnable() {

            @Override
            public void run() {
                if(mediaPlayer != null){
                    int mCurrentPosition = mediaPlayer.getCurrentPosition() ;
                    seekBar.setProgress(mCurrentPosition);
                }
                mHandler.postDelayed(this, 50);
            }
        });

        //mediaPlayer.start();
        //btnPlayPause.setText(R.string.btnPause);

        //ONLINE PLAYING
        surfaceView2 = findViewById(R.id.surfaceView2) ;
        seekBar2 = findViewById( R.id.seekBar2) ;
        btnPlayPause2  = findViewById( R.id.btnPlayPause2)  ;
        buffer = findViewById(R.id.txtBuffer) ;

        btnPlayPause2.setText(R.string.btnBuff);
        mediaPlayer2 = new MediaPlayer();
        try {
            //ADD   android:usesCleartextTraffic="true" for http access
            //mediaPlayer2.setAudioStreamType(AudioManager.STREAM_MUSIC);
            //mediaPlayer2.setDataSource("http://scienceandfilm.org/uploads/videos/files/The_Rain_Collector_(2015)_TRAILER-HD.mp4");
            mediaPlayer2.setDataSource("http://scienceandfilm.org/uploads/videos/files/Kardia_-_a_film_by_Su_Rynard_-_Trailer.mp4");
            // add <uses-permission android:name="android.permission.INTERNET"/> for internet access
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Unable to play from internet", Toast.LENGTH_SHORT).show();
        }

        mediaPlayer2.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer2) {
                mediaPlayer2.start();
                // to make seekbar slow or bigger
                seekBar2.setMax( mediaPlayer.getDuration() * 20);
                btnPlayPause2.setText(R.string.btnPause);
                buffer.setVisibility( View.INVISIBLE );
            }
        });

        mediaPlayer2.prepareAsync();

        surfaceView2.setKeepScreenOn(true);
        SurfaceHolder surfaceHolder2 = surfaceView2.getHolder();
        surfaceHolder2.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder2) {
                mediaPlayer2.setDisplay(surfaceHolder2);
            }
            @Override
            public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {
            }
            @Override
            public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {
            }
        });

        seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean user) {
                if(mediaPlayer2 != null && user){
                    mediaPlayer2.seekTo(progress);
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        mediaPlayer2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer2) {
                btnPlayPause2.setText(R.string.btnPlay);
                mediaPlayer2.seekTo(0);
            }
        });

        btnPlayPause2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ( mediaPlayer2.isPlaying() ){
                    mediaPlayer2.pause();
                    btnPlayPause2.setText(R.string.btnPlay);
                }
                else {
                    mediaPlayer2.start();
                    btnPlayPause2.setText(R.string.btnPause);
                }
            }
        });

        Handler mSeekbarUpdateHandler = new Handler();
        Runnable mUpdateSeekbar = new Runnable() {
            @Override
            public void run() {
                seekBar2.setProgress(mediaPlayer2.getCurrentPosition() );
                mSeekbarUpdateHandler.postDelayed(this, 50);
            }
        };

        mSeekbarUpdateHandler.postDelayed(mUpdateSeekbar, 0);


        //mediaPlayer2.start();

    }
}
