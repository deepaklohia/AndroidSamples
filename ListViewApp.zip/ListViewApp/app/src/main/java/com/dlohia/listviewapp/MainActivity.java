package com.dlohia.listviewapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public ListView listView;
    public String arr[] = {"itm0" , "itm1" , "itm2"  , "itm3"} ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listviewA) ;

        // custom adapter option 1
        LohiaAdapter la  = new LohiaAdapter(  this ,
                R.layout.activity_lohia_adapter , arr  )  ;
        listView.setAdapter(la );

        /*

        // BUILT IN LISTVIEW
        //setting values to array adapter >> build in adapter
        ArrayAdapter ad  = new ArrayAdapter(  this ,
                    android.R.layout.simple_list_item_1 , arr  )  ;
        listView.setAdapter(ad );

        // this is for the built in Adapter
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //Toast.makeText(context,  "you click on :"  + position , Toast.LENGTH_SHORT).show();
            }
        });
         */


    }
}