package com.dlohia.listviewapp;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class LohiaAdapter extends ArrayAdapter <String> {
    private final String[] arr ;
    private final Context context ;
    public final int resourceID ;

    public LohiaAdapter (@NotNull Context context , int resourceID , @NotNull String[] arr){
        super( context , resourceID , arr );
        this.context = context ;
        this.resourceID  = resourceID  ;
        this.arr = arr  ;
    }

    @Nullable
    @Override
    public  String getItem(int position) {
        return arr[position] ;
    }

    @Nullable
    @Override
    public View getView(int position , @Nullable View convertView , @Nullable ViewGroup parent){
        // we are converting the layout to android view for list
        convertView = LayoutInflater.from(getContext()).inflate( R.layout.activity_lohia_adapter , parent , false     ) ;
        TextView t  = convertView.findViewById(R.id.textView) ;
        ImageView i = convertView.findViewById(R.id.imageView) ;
        t.setText( getItem(position));
        i.setImageResource( R.drawable.youtube_48dp );

        //here is click listner
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,  "you click on :"  + position , Toast.LENGTH_SHORT).show();
            }
        });

        return convertView ;
    }
}